package com.example.Sourav.s_To_do_List.Service;

import com.example.Sourav.s_To_do_List.Model.TaskEntity;
import com.example.Sourav.s_To_do_List.Repository.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TaskService {

    @Autowired
    private TaskRepository taskRepository;

    // Get all tasks
    public List<TaskEntity> getAllTasks() {
        return taskRepository.findAll();
    }

    // Get task by ID
    public TaskEntity getTaskById(Long id) {
        return taskRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid task ID: " + id));
    }

    // Save or update task
    public TaskEntity saveTask(TaskEntity task) {
        return taskRepository.save(task);  // If task has an ID, it will update; otherwise, it will insert.
    }

    // Delete task by ID
    public void deleteTask(Long id) {
        taskRepository.deleteById(id);
    }
}