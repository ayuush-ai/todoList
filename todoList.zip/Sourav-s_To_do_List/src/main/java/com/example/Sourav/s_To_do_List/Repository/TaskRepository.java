package com.example.Sourav.s_To_do_List.Repository;

import com.example.Sourav.s_To_do_List.Model.TaskEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TaskRepository extends JpaRepository<TaskEntity, Long> {
    // Custom query methods can be added here if needed
}
