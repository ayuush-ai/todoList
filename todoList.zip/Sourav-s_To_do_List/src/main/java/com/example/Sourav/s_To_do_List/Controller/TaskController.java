package com.example.Sourav.s_To_do_List.Controller;

import com.example.Sourav.s_To_do_List.Model.TaskEntity;
import com.example.Sourav.s_To_do_List.Service.TaskService;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.ByteArrayOutputStream;

@Controller
@RequestMapping("/tasks")
public class TaskController {

    @Autowired
    private TaskService taskService;

    // Display task list
    @GetMapping
    public String listTasks(Model model) {
        model.addAttribute("tasks", taskService.getAllTasks());
        return "task-list";  // Thymeleaf template to render the task list
    }

    // Display add or edit task form
    @GetMapping("/add")
    public String addTaskForm(Model model) {
        model.addAttribute("task", new TaskEntity());  // For creating a new task
        return "task-form";  // Thymeleaf template for adding/editing task
    }

    // Display task edit form
    @GetMapping("/{id}/edit")
    public String editTaskForm(@PathVariable Long id, Model model) {
        TaskEntity task = taskService.getTaskById(id);  // Fetch task by ID
        model.addAttribute("task", task);  // Add task data to the model
        return "task-form";  // Thymeleaf template for editing task
    }

    // Save or update task
    @PostMapping("/save")
    public String saveTask(@ModelAttribute TaskEntity task) {
        taskService.saveTask(task);  // Save or update the task via TaskService
        return "redirect:/tasks";  // Redirect to task list page
    }

    // Delete task by ID
    @PostMapping("/{id}/delete")
    public String deleteTask(@PathVariable Long id) {
        taskService.deleteTask(id);  // Delete the task via TaskService
        return "redirect:/tasks";  // Redirect back to the task list page
    }

    // Generate PDF for task by ID
    @GetMapping("/{id}/export/pdf")
    public ResponseEntity<byte[]> exportToPDF(@PathVariable Long id) {
        // Fetch task from the database
        TaskEntity taskEntity = taskService.getTaskById(id);

        // Create a PDF document
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PdfWriter writer = new PdfWriter(outputStream);
        PdfDocument pdfDocument = new PdfDocument(writer);
        Document document = new Document(pdfDocument);

        try {
            // Only include Title and Body in the PDF
            document.add(new Paragraph("Title: " + taskEntity.getTitle()));
            document.add(new Paragraph("Body: " + taskEntity.getBody()));
        } finally {
            document.close(); // Ensure the document is closed
        }

        // Return the PDF as a byte array
        byte[] pdfBytes = outputStream.toByteArray();
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=task_" + taskEntity.getId() + ".pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdfBytes);
    }
}
