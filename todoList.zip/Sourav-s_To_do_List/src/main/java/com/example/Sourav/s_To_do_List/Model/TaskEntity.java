package com.example.Sourav.s_To_do_List.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class TaskEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private String body;

    // Task can be represented as an int: 1 = Yes, 0 = No
    private int task;  // Use Boolean if needed for true/false

    // Default constructor
    public TaskEntity() {}

    // Constructor with parameters
    public TaskEntity(String title, String body, int task) {
        this.title = title;
        this.body = body;
        this.task = task;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public int getTask() {
        return task;
    }

    public void setTask(int task) {
        this.task = task;
    }

    // Optional: You can use a method to return a Boolean if preferred
    public boolean isTask() {
        return task == 1;
    }

    public void setTask(Boolean task) {
        this.task = task ? 1 : 0;
    }
}
